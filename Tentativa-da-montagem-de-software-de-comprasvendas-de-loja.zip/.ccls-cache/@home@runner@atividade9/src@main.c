/*
 * PREENCHA O NOME E RA DA DUPLA!!!!!!
 *
 * Nome: Lucas Silva Anholeto
 * RA: 21.02145-7
 *
 * Nome: Vitor Kato
 * RA: 21.02149-0
 *
 * ENTREGUE APENAS O ARQUIVO MAIN.C
 *
 */

#include "../include/sqlite3.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define MAX 100

// Protótipo das funções

void print_db(sqlite3_stmt *stmt);
int menu();
int nova_venda(sqlite3 *db, sqlite3_stmt *stmt, int *venda_em_progresso);
int adicionar_no_carrinho(sqlite3 *db, sqlite3_stmt *stmt, int id_venda);
void fechar_venda(sqlite3 *db, sqlite3_stmt *stmt, int id,
                  int *venda_em_progresso);
void gerenciar_estoque(sqlite3 *db, sqlite3_stmt *stmt);
void cadastrar_produto(sqlite3 *db, sqlite3_stmt *stmt);
void editar_produto(sqlite3 *db, sqlite3_stmt *stmt, int codigo);
void deletar_produto(sqlite3 *db, sqlite3_stmt *stmt);
void ler_string(char s[MAX]);

// main

int main() {
  system("clear");
  sqlite3 *db = NULL;
  sqlite3_stmt *stmt = NULL;
  int resp = 0;
  int id_venda = 0;
  int venda_em_progresso = 0;
  sqlite3_open("Lojinha.db", &db);

  while (resp != 5) {
    resp = menu();
    switch (resp) {

    case 7:
      deletar_produto(db, stmt);
      break;

    case 6:
      system("clear");
      sqlite3_prepare(db, "SELECT * FROM estoque", -1, &stmt, NULL);
      print_db(stmt);
      sleep(5);
      system("clear");
      break;

    case 5:
      printf("\033[31mENCERRANDO O PROGRAMA...\n");
      sleep(5);
      break;

    case 4:
      gerenciar_estoque(db, stmt);
      printf("\nVOLTANDO PARA O MENU...\n");
      sleep(5);
      system("clear");
      break;

    case 3:
      fechar_venda(db, stmt, id_venda, &venda_em_progresso);
      break;

    case 2:

      system("clear");
      sqlite3_prepare(db, "SELECT * FROM estoque", -1, &stmt, NULL);
      print_db(stmt);
      adicionar_no_carrinho(db, stmt, id_venda);

      break;

    case 1:
      id_venda = nova_venda(db, stmt, &venda_em_progresso);
      break;
    }
  }
  return 0;
}

int menu() {
  int resposta;

  printf("ESCOLHA UMA DAS OPÇÕES ABAIXO:\n");
  printf("1) REALIZAR NOVA VENDA\n2) ADICIONAR AO CARRINHO\n3) FECHAR VENDA\n");
  printf("4) GERENCIAR ESTOQUE\n5) ENCERRAR O PROGRAMA\n6) VISUALIZAR O "
         "ESTOQUE\n7) DELETAR PRODUTO\n");
  scanf("%i", &resposta);
  return resposta;
}

int nova_venda(sqlite3 *db, sqlite3_stmt *stmt, int *venda_em_progresso) {
  char request[100];
  int id_max = 0;
  system("clear");

  if (*venda_em_progresso) {
    printf(
        "\033[31mENCERRE A VENDA ATUAL ANTES DE ABRIR UMA NOVA\n\n\n\033[0m");
    sprintf(request, "SELECT MAX(codigo) FROM vendas;");
    sqlite3_prepare(db, request, -1, &stmt, NULL);
    sqlite3_step(stmt);
    id_max = sqlite3_column_int(stmt, 0);
    return id_max;
  } else {

    sprintf(request, "SELECT MAX(codigo) FROM vendas;");
    sqlite3_prepare(db, request, -1, &stmt, NULL);
    sqlite3_step(stmt);
    id_max = sqlite3_column_int(stmt, 0);
    *venda_em_progresso = 1;
    return id_max++;
  }
}

int adicionar_no_carrinho(sqlite3 *db, sqlite3_stmt *stmt, int id_venda) {
  int codigo;
  int quant;
  char request[MAX];

  printf("Digite o código do produto:\n");
  scanf("%i", &codigo);
  printf("Digite a quantidade de produto(s):\n");
  scanf("%i", &quant);

  sprintf(request, "SELECT nome FROM estoque WHERE codigo = %i;", codigo);
  sqlite3_prepare(db, request, -1, &stmt, NULL);
  sqlite3_step(stmt);
  if (sqlite3_column_text(stmt, 0) == NULL) {
    printf("Produto não consta no estoque.");
    return 0;
  } else {
    sqlite3_finalize(stmt);
    sprintf(request, "SELECT quant FROM estoque WHERE codigo = %i;", codigo);
    sqlite3_prepare(db, request, -1, &stmt, NULL);
    sqlite3_step(stmt);
    int estoque = sqlite3_column_int(stmt, 0);
    sqlite3_finalize(stmt);

    if (estoque < quant) {
      printf("Quantidade desejada insuficiente, usando o maximo do estoque");
      return 0;
    } else {
      printf("id = %i", id_venda);
      sprintf(request,
              "INSERT INTO vendas (idvenda,codigo,quant,preco) "
              "VALUES(%i,%i,%i,%i);",
              id_venda, codigo, quant, 10);
      sqlite3_exec(db, request, -1, &stmt, NULL);

      sprintf(request, "SELECT * FROM vendas WHERE idvenda = %i", id_venda);
      sqlite3_prepare(db, request, -1, stmt, NULL);
      print_db(stmt);
    }
  }
}

void fechar_venda(sqlite3 *db, sqlite3_stmt *stmt, int id,
                  int *venda_em_progresso) {
  char request[100];
  float preco;
  system("clear");

  if (*venda_em_progresso) {

    sprintf(request, "SELECT * FROM vendas WHERE idVenda IS %i;", id);
    sqlite3_prepare(db, request, -1, &stmt, NULL);
    print_db(stmt);

    sprintf(request, "SELECT SUM(preco*quant) from vendas WHERE idvenda = %i;",
            id);
    sqlite3_prepare(db, request, -1, &stmt, NULL);
    sqlite3_step(stmt);
    preco = sqlite3_column_double(stmt, 0);
    printf("Valor total da compra eh de R$%.2f\n\n\n", preco);
    *venda_em_progresso = 0;
  }

  else {
    printf("\033[31mNÃO HÁ NENHUMA COMPRA EM ABERTO, APERTE (1) PARA ABRIR UMA "
           "COMPRA\n\n\n\033[0m");
  }
}

void gerenciar_estoque(sqlite3 *db, sqlite3_stmt *stmt) {
  system("clear");
  printf("\033[35m");
  char request[200];
  int codigo;

  sqlite3_prepare(db, "SELECT * FROM estoque", -1, &stmt, NULL);
  print_db(stmt);

  printf("\n\034[3mDigite o código do poduto a ser adicionado:\n");
  scanf("%i", &codigo);
  system("clear");
  sprintf(request, "SELECT nome FROM estoque WHERE codigo = %i;", codigo);
  sqlite3_prepare(db, request, -1, &stmt, NULL);
  sqlite3_step(stmt);

  if (sqlite3_column_text(stmt, 0) == NULL) {
    sqlite3_finalize(stmt);
    cadastrar_produto(db, stmt);
  }

  else {
    editar_produto(db, stmt, codigo);
  }

  sqlite3_prepare(db, "SELECT * FROM estoque", -1, &stmt, NULL);
  print_db(stmt);
}

void cadastrar_produto(sqlite3 *db, sqlite3_stmt *stmt) {
  char nome[20];
  char request[MAX];
  int quantidade;
  float preco;
  int ID;

  sqlite3_prepare(db, "SELECT COUNT(*) FROM estoque;", -1, &stmt, NULL);
  sqlite3_step(stmt);
  ID = sqlite3_column_int(stmt, 0) + 1;
  printf("Qual o nome do produto a ser adicionado?: ");
  ler_string(nome);
  printf("Qual o preço do produto a ser adicionado?: \n");
  scanf("%f", &preco);
  printf("Qual a quantidade de produtos a serem adicionados?: \n");
  scanf("%i", &quantidade);

  sprintf(
      request,
      "INSERT INTO estoque (codigo,nome,quant,preco) VALUES(%i,'%s',%i,%.2f);",
      ID, nome, quantidade, preco);
  sqlite3_exec(db, request, -1, &stmt, NULL);
}

void editar_produto(sqlite3 *db, sqlite3_stmt *stmt, int codigo) {
  int quantidade;
  float preco;
  char request[100];
  sqlite3_finalize(stmt);

  printf("Quantos itens serão adicionados?: \n");
  scanf("%i", &quantidade);

  printf("Qual o preço do item adicionado?: \n");
  scanf("%f", &preco);

  sprintf(request, "UPDATE estoque SET quant = quant+%i WHERE codigo = %i;",
          quantidade, codigo);
  sqlite3_exec(db, request, -1, &stmt, NULL);
  sprintf(request, "UPDATE estoque SET preco = %.2f WHERE codigo = %i;", preco,
          codigo);
  sqlite3_exec(db, request, -1, &stmt, NULL);
}

void deletar_produto(sqlite3 *db, sqlite3_stmt *stmt) {
  int codigo;
  char request[100];

  printf("DIGITE O NOME DO PRODUTO PARA DELETA-LO DO ESTOQUE: ");
  scanf("%i", &codigo);

  sprintf(request, "DELETE FROM estoque WHERE codigo IS %i", codigo);
  sqlite3_exec(db, request, -1, &stmt, NULL);
  system("clear");
  sqlite3_prepare(db, "SELECT * FROM estoque", -1, &stmt, NULL);
  print_db(stmt);
  sleep(5);
  system("clear");
}

void print_db(sqlite3_stmt *stmt) {
  for (int i = 0; i < sqlite3_column_count(stmt); i++)
    printf("%s\t", sqlite3_column_name(stmt, i));
  printf("\n");

  while (sqlite3_step(stmt) != SQLITE_DONE) {

    for (int i = 0; i < sqlite3_column_count(stmt); i++)
      printf("%s\t", sqlite3_column_text(stmt, i));
    printf("\n");
  }
  sqlite3_finalize(stmt);
}

void ler_string(char s[MAX]) {
  setbuf(stdin, 0);
  fgets(s, MAX, stdin);
  if (s[strlen(s) - 1] == '\n') {
    s[strlen(s) - 1] = '\0';
  }
}